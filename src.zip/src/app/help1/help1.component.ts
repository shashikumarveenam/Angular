import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help1',
  templateUrl: './help1.component.html',
  styleUrls: ['./help1.component.css']
})
export class Help1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
