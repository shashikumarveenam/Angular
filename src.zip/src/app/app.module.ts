import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HelpComponent } from './help/help.component';
import { AppDemoComponent } from './app-demo/app-demo.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { Help1Component } from './help1/help1.component';

const routes = [
  {
    path: '', component: AppDemoComponent,
    children: [
      {
        path: 'help/:uid', component: HelpComponent,
        children: [
          {path: 'help1', component: Help1Component}
        ]
      },
    ]
  },
  
]

@NgModule({
  declarations: [
    AppComponent,
    HelpComponent,
    AppDemoComponent,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
