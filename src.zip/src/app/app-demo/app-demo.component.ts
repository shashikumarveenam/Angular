import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-demo',
  templateUrl: './app-demo.component.html',
  styleUrls: ['./app-demo.component.css']
})
export class AppDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
